package controller;

/****************************************LMS*****************************************************************************
 * @author      : Group 9 
 * Date         : 10/16/2016
 * Description  : Added Buttons and redirect all the program from it. All the pages will show in the main frame panel
 *               (in splitter). 
 * Version      : 1.00  
 * 
 ************************************************************************************************************************/

import java.io.IOException;

import business.Auth;
import business.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;

public class MainFrameController  
{
    @FXML private Button btnInvoice;
    @FXML private Button btnPrescription;
    @FXML private Label lblUserId;
    @FXML private Pane functionPane;
    @FXML private VBox butionsControl;
    @FXML private Button btnAddPatient;
    @FXML private Button btnLogout;
    @FXML private Button btnAddDoctor;
    @FXML private Label lblLoginAs;
    @FXML private VBox header; 
    @FXML private Button btnPayment;
    @FXML private Button btnMedicine;
    @FXML private Button btnInsurance;
    @FXML private Button btnClinic;
    @FXML private Button btnPaycheck;
   
   
    @FXML public void onAddDoctorClick(ActionEvent event)
    {
        try
        {	
    		Parent child = FXMLLoader.load(getClass().getResource("/view/Doctors.fxml"));
    		functionPane.getChildren().clear();
    		functionPane.getChildren().add(child);
        }
        catch (IOException e)
        {
        	e.printStackTrace();
        }
    }

    @FXML public void onAddPatientClick(ActionEvent event)
    {
    	try 
    	{  	
    		Parent child = FXMLLoader.load(getClass().getResource("/view/Patient.fxml"));
    		functionPane.getChildren().clear();
    		functionPane.getChildren().add(child);
        }
    	catch (IOException e)
    	{
        	e.printStackTrace();
       	}
    }


    @FXML public void oninvoiceClick(ActionEvent event)
    {
    	try 
    	{  	
    		Parent child = FXMLLoader.load(getClass().getResource("/view/Invoice.fxml"));
    		functionPane.getChildren().clear();
    		functionPane.getChildren().add(child);
        }
    	catch (IOException e) 
    	{
        	e.printStackTrace();
       	}
    }
    
    
    @FXML public void onPaymentClick(ActionEvent event)
    {
    	try 
    	{  	
    		Parent child = FXMLLoader.load(getClass().getResource("/view/Payment.fxml"));
    		functionPane.getChildren().clear();
    		functionPane.getChildren().add(child);
        }
    	catch (IOException e) 
    	{
        	e.printStackTrace();
       	}
    }
    
    
    @FXML public void onPrescriptionClick(ActionEvent event)
    {
    	try 
    	{  	
    		Parent child = FXMLLoader.load(getClass().getResource("/view/Prescription.fxml"));
    		functionPane.getChildren().clear();
    		functionPane.getChildren().add(child);
        }
    	catch (IOException e) 
    	{
        	e.printStackTrace();
       	}
    }    
    
    @FXML public void onInsuranceClick(ActionEvent event)
    {
    	try 
    	{  	
    		Parent child = FXMLLoader.load(getClass().getResource("/view/Insurance.fxml"));
    		functionPane.getChildren().clear();
    		functionPane.getChildren().add(child);
        }
    	catch (IOException e) 
    	{
        	e.printStackTrace();
       	}
    }    

    @FXML public void onClinicClick(ActionEvent event)
    {
    	try 
    	{  	
    		Parent child = FXMLLoader.load(getClass().getResource("/view/Clinic.fxml"));
    		functionPane.getChildren().clear();
    		functionPane.getChildren().add(child);
        }
    	catch (IOException e) 
    	{
        	e.printStackTrace();
       	}
    }    
    
    @FXML public void onPaycheckClick(ActionEvent event)
    {
    	try 
    	{  	
    		Parent child = FXMLLoader.load(getClass().getResource("/view/Paycheck.fxml"));
    		functionPane.getChildren().clear();
    		functionPane.getChildren().add(child);
        }
    	catch (IOException e) 
    	{
        	e.printStackTrace();
       	}
    }    
    
    @FXML public void onMedicineClick(ActionEvent event) 
    {
    	try 
    	{  	
    		Parent child = FXMLLoader.load(getClass().getResource("/view/Medicine.fxml"));
    		functionPane.getChildren().clear();
    		functionPane.getChildren().add(child);
        }
    	catch (IOException e)
    	{
        	e.printStackTrace();
       	}
    }
    @FXML
	public void logoutClick(ActionEvent event) {
		try {
			Stage stage = new Stage();
			Window window = header.getScene().getWindow();
			if (window instanceof Stage) {
				((Stage) window).close();
			}
			Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
			stage.setTitle("Library Management System");
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
         

//	getting Id and Authorization role from login form
    public void initData(String username, String Rolename) 
    {
		lblUserId.setText(username);
		lblLoginAs.setText(Rolename);	
	}

    public void RoleFuction(User user)
    {
		if (user.getAuthorization().equals(Auth.Doctor))
		{
			butionsControl.getChildren().remove(btnAddPatient);
			butionsControl.getChildren().remove(btnAddDoctor);
			butionsControl.getChildren().remove(btnPayment);
			butionsControl.getChildren().remove(btnInsurance);
			butionsControl.getChildren().remove(btnClinic);
		}
		else if (user.getAuthorization().equals(Auth.Adminnistrative))
		{
			butionsControl.getChildren().remove(btnPrescription);
			butionsControl.getChildren().remove(btnInvoice);
			butionsControl.getChildren().remove(btnMedicine);
			butionsControl.getChildren().remove(btnPaycheck);
		}	
	}
}
