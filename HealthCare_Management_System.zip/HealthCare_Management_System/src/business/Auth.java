package business;

import java.io.Serializable;

public enum Auth implements Serializable
{
	Adminnistrative, Doctor;
}
