package business;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Login implements Initializable 
{
	@FXML private TextField txtUsername;
	@FXML private TextField txtPassword;
	@FXML private TextField cmbUsertype;
	@FXML private Label     lblMessage;
	

	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1)
	{
	}
	
	@FXML public void onClickLogin(ActionEvent event)
	{
		validateLogin();
	}
	
	public boolean validateLogin()
	{
		if(txtUsername.getText().equals(""))
		{
			lblMessage.setText("Member ID: Value is required.");
			txtUsername.requestFocus();
			return false;
		}
		return true;
	}

}
